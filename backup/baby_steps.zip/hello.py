from flask import Flask, redirect, url_for, request, render_template

app = Flask(__name__)

@app.route('/')
def starter():
    return 'Make this shit work'

@app.route('/hello/<user>')
def hello(user):
    return render_template('hello.html', name = user)


@app.route('/admin')
def admin():
    return 'Hello Admin'

@app.route('/guest/<guest>')
def guest(guest):
    return 'Hello {}!'.format(guest)

@app.route('/user/<name>')
def user(name):
    if name == 'admin':
        return redirect(url_for('admin'))
    else:
        return redirect(url_for('guest', guest=name))

@app.route('/success/<name>')
def success(name):
    return 'Welcome %s' % name

@app.route('/login', methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
        # user = request.form['form-name']
        user = request.form.get('form-name')
        return redirect(url_for('success', name = user))

@app.route('/home')
def home():
    return render_template('homesearch.html')

"""
Preferred Way
"""

# @app.route('/homepage', methods=['GET', 'POST'])
# def homepage():
#     if request.method == 'POST':
#         name = request.form.get('search-term')
#         return redirect(url_for('calculate', term = name))

# @app.route('/calculate/<term>')
# def calculate(term):
#     # Do somthing to the database over here
#     calculated_term = term
#     return redirect(url_for('search', result_term = calculated_term))

# @app.route('/search/<result_term>')
# def search(result_term):
#     return render_template('searchresult.html', result_html = result_term )


"""
Alternative 1
"""

@app.route('/homepage', methods=['GET', 'POST'])
def homepage():
    if request.method == 'POST':
        name = request.form.get('search-term')
        return render_template('searchresult.html', result_html = name )


if __name__ == '__main__':
    app.run(debug=True, port=2000)
