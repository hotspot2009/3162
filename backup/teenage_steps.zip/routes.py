from flask import Flask, render_template, redirect, url_for, request
import pickle as pk
import math
import random

# Import processed datas from folder

infile = open("codes/Stored Data/sample_aspect_info.pickle", "rb")
aspect_info = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/sample_hotel_info.pickle", "rb")
hotels = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/aspect_dict.pickle", "rb")
aspect_dict = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/city_dict.pickle", "rb")
city_dict = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/hotel_dict.pickle", "rb")
hotel_dict = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/timeline_dict.pickle", "rb")
timeline_dict = pk.load(infile)
infile.close()

app = Flask(__name__)

     
@app.route("/")
def index():
    return render_template('index.html', aspects = aspect_dict,
                                         cities = city_dict)

@app.route("/homepage", methods=['GET', 'POST'])
def homepage():
    if request.method == "POST":
        input_search_term = (request.form.get("input-search-term")).lower()
        input_location = request.form.get("input-location")
        # data = normalize_data(input_search_term, input_location) 
        return render_template('search.html', search_term = input_search_term, 
                                              location_area = input_location,
                                              timeline = timeline_dict,
                                              hotel_info = hotels,
                                              data = aspect_info)


def min_max(arr):
    _min = math.inf
    _max = -math.inf

    for i in range(len(arr)):
        if arr[i] < _min:
            _min = arr[i]

        if arr[i] > _max:
            _max = arr[i]

    new_arr = []
    for i in range(len(arr)):
        new_val = (((arr[i] - _min) / (_max - _min)) * (1 - (-1))) - 1
        new_arr.append(new_val)

    return new_arr

def normalize_data(search, location):
    count = 0
    collection = []
    for key, value in timeline_dict.items():
        if count == 4:
            break
        else:
            data = timeline_dict[key][location][search]
            collection.append(data)
            count += 1

    results_aspects = {}

    for x in collection:
        for y in x:
            if y[0] in results_aspects:
                results_aspects[y[0]] += y[1]
            else:
                results_aspects.setdefault(y[0], y[1])
    
    array_of_num = []

    for key, value in results_aspects.items():
        array_of_num.append(value)

    normalize_num = min_max(array_of_num)

    count = 0
    normalize_array = []
    for key, value in results_aspects.items():
        if normalize_num[count] > 0:
            normalize_array.append((normalize_num[count]*100, key))
        count += 1

    normalize_array.sort(reverse=True)

    return normalize_array    

if __name__ == "__main__":
    app.run(debug=True, port=1000)