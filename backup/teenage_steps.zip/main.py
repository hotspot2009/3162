import pickle as pk
import sys

sys.path.insert(0, './codes/Library/')
from normalize import normalize_data

infile = open("codes/Stored Data/aspect_dict.pickle", "rb")
aspect_dict = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/city_dict.pickle", "rb")
city_dict = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/hotel_dict.pickle", "rb")
hotel_dict = pk.load(infile)
infile.close()

infile = open("codes/Stored Data/timeline_dict.pickle", "rb")
timeline_dict = pk.load(infile)
infile.close()

data = normalize_data('bathroom', 'Paris, France', timeline_dict)
print(data)